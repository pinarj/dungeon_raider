import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import random
import math
import sys
import time
import os

# Initialize pygame
pygame.init()
screen_width, screen_height = 880, 620
screen = pygame.display.set_mode((screen_width, screen_height), DOUBLEBUF | OPENGL)
pygame.display.set_caption("Dungeon Raider 3D - Enhanced")

# Camera settings
CAMERA_DISTANCE = 12  # Increased for better view
CAMERA_HEIGHT = 5  # Higher camera angle
CAMERA_ANGLE = 0
CAMERA_SENSITIVITY = 2

# Game settings
PLAYER_SPEED = 0.15
CHASER_BASE_SPEED = 0.03
MAX_LEVEL = 3

# Colors
BLUE = (0, 0.5, 1)
RED = (1, 0, 0)
YELLOW = (1, 1, 0)
GREEN = (0, 1, 0)
GRAY = (0.5, 0.5, 0.5)
PURPLE = (0.5, 0, 0.5)

# Fonts
font = pygame.font.SysFont("Arial", 32, True)
large_font = pygame.font.SysFont("Arial", 64, True)


def load_texture(image_path, default_color=None):
    """Load texture with error handling and fallback color"""
    try:
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Texture not found: {image_path}")

        texture_surface = pygame.image.load(image_path).convert_alpha()
        texture_data = pygame.image.tostring(texture_surface, "RGBA", True)
        width, height = texture_surface.get_size()

        texture_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, texture_data)
        return texture_id
    except Exception as e:
        print(f"Error loading texture: {e}")
        if default_color:
            # Create a colored texture as fallback
            texture_id = glGenTextures(1)
            glBindTexture(GL_TEXTURE_2D, texture_id)
            color_data = [int(c * 255) for c in default_color] + [255]  # RGBA
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, bytes(color_data))
            return texture_id
        return None


def draw_3d_sprite(x, y, z, width, height, texture=None, color=None, rotation=0):
    """Draw a 2D sprite in 3D space that always faces the camera"""
    glPushMatrix()
    glTranslatef(x, y, z)

    # Rotate to face camera (billboarding)
    glRotatef(-CAMERA_ANGLE, 0, 0, 1)
    glRotatef(90, 1, 0, 0)  # Stand upright

    if texture:
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, texture)
        glColor3f(1, 1, 1)  # White to show texture properly
    elif color:
        glColor3f(*color)

    half_w = width / 2
    half_h = height / 2

    glBegin(GL_QUADS)
    glTexCoord2f(0, 0);
    glVertex3f(-half_w, -half_h, 0)
    glTexCoord2f(1, 0);
    glVertex3f(half_w, -half_h, 0)
    glTexCoord2f(1, 1);
    glVertex3f(half_w, half_h, 0)
    glTexCoord2f(0, 1);
    glVertex3f(-half_w, half_h, 0)
    glEnd()

    if texture:
        glDisable(GL_TEXTURE_2D)

    glPopMatrix()


class Entity:
    def __init__(self, x, y, z, width, height, texture=None, color=None):
        self.x = x
        self.y = y
        self.z = z
        self.width = width
        self.height = height
        self.texture = texture
        self.color = color
        self.treasure_opening = False
        self.treasure_anim_timer = 0

    def draw(self):
        draw_3d_sprite(self.x, self.y, self.z, self.width, self.height, self.texture, self.color)

    def get_rect(self):
        return pygame.Rect(self.x - self.width / 2, self.y - self.height / 2, self.width, self.height)


class Player(Entity):
    def __init__(self, x, y, z):
        super().__init__(x, y, z, 1.5, 2.0)  # Taller sprite
        self.speed = PLAYER_SPEED
        self.rotation = 0

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def rotate(self, angle):
        self.rotation = (self.rotation + angle) % 360


class Game:
    def __init__(self):
        self.obstacles = []
        self.treasure_opening = False
        self.treasure_anim_timer = 0
        self.reset_game()

    def reset_game(self):
        self.level = 1
        self.score = 0
        self.timer = 60
        self.last_time = time.time()
        self.game_over = False
        self.game_over_time = 0
        self.load_assets()
        self.init_entities()

    def load_assets(self):
        # Create assets directory if missing
        if not os.path.exists("assets"):
            os.makedirs("assets")
            print("Created 'assets' directory. Please add your texture files.")

        # Load textures with fallback colors
        self.textures = {
            "player": load_texture("assets/player.png", BLUE),
            "chaser": load_texture("assets/chaser.png", RED),
            "treasure": load_texture("assets/treasure.png", YELLOW),
            "treasure_open": load_texture("assets/acik_sandik.png", YELLOW),
            "gate": load_texture("assets/gate.png", GREEN),
            "obstacle": load_texture("assets/obstacle.png", GRAY),
            "floor1": load_texture("assets/floor.png"),  # varsayılan zemin
            "floor2": load_texture("assets/floor2.png"),  # senin yüklediğin dosya
            "floor3": load_texture("assets/floor3.png"),  # varsa farklı bir zemin daha
        }

    def init_entities(self):
        # Player with texture
        self.player = Player(0, 0, 0)
        self.player.texture = self.textures["player"]
        self.treasure_opening = False
        self.treasure_anim_timer = 0

        # Chaser with texture
        self.chaser = Entity(
            random.randint(-15, 15),
            random.randint(-15, 15),
            0,
            1.5, 2.0,
            self.textures["chaser"]
        )

        self.chaser_speed = CHASER_BASE_SPEED + self.level * 0.01
        self.obstacles = self.generate_obstacles(min(3 + self.level, 7))

        # Treasure with texture
        self.treasure = self.spawn_entity(1.8, 1.8, self.textures["treasure"])

        # Gate with texture
        self.gate = self.spawn_entity(3.8, 3.0, self.textures["gate"])
        self.gate_active = False

    def generate_obstacles(self, count):
        obstacles = []
        for _ in range(count):
            while True:
                x = random.randint(-18, 18)
                y = random.randint(-18, 18)
                if math.hypot(x, y) > 8:  # Keep away from player start
                    obstacle = Entity(
                        x, y, 0,
                        random.uniform(1.2, 2.0),
                        random.uniform(1.2, 2.0),
                        self.textures["obstacle"]
                    )
                    if not self.check_collision(obstacle, [self.player]):
                        obstacles.append(obstacle)
                        break
        return obstacles

    def spawn_entity(self, width, height, texture=None, color=None):
        while True:
            x = random.randint(-15, 15)
            y = random.randint(-15, 15)
            entity = Entity(x, y, 0, width, height, texture, color)
            if not self.check_collision(entity, [self.player] + self.obstacles):
                return entity

    def check_collision(self, entity, entities):
        rect1 = entity.get_rect()
        for other in entities:
            rect2 = other.get_rect()
            if rect1.colliderect(rect2):
                return True
        return False

    def draw_text(self, text, font, color, x, y):
        # OpenGL ayarlarını kapat
        glDisable(GL_TEXTURE_2D)
        glDisable(GL_DEPTH_TEST)
        glDisable(GL_LIGHTING)

        # Pygame'de metni yüzeye çiz
        text_surface = font.render(text, True, (255, 255, 255))  # 🔥 Beyaz RGB garanti
        text_data = pygame.image.tostring(text_surface, "RGBA", True)
        width, height = text_surface.get_size()

        # OpenGL 2D ayarı
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        gluOrtho2D(0, screen_width, 0, screen_height)

        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()

        # Metni çiz
        glRasterPos2f(x, screen_height - y)
        glDrawPixels(width, height, GL_RGBA, GL_UNSIGNED_BYTE, text_data)

        # Geriye dön
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)
        glPopMatrix()

        glEnable(GL_DEPTH_TEST)

    def setup_camera(self):
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(60, (screen_width / screen_height), 0.1, 100.0)

        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

        # Third-person camera with better view
        rad_angle = math.radians(CAMERA_ANGLE)
        cam_x = self.player.x - CAMERA_DISTANCE * math.sin(rad_angle)
        cam_y = self.player.y - CAMERA_DISTANCE * math.cos(rad_angle)
        cam_z = CAMERA_HEIGHT

        # Look slightly ahead of player
        look_ahead = 5
        look_x = self.player.x + math.sin(rad_angle) * look_ahead
        look_y = self.player.y + math.cos(rad_angle) * look_ahead

        gluLookAt(
            cam_x, cam_y, cam_z,
            look_x, look_y, self.player.z,
            0, 0, 1
        )

    def draw_floor(self):
        # Level'e göre zemin seçimi
        floor_key = f"floor{self.level}"
        floor_texture = self.textures.get(floor_key)

        if floor_texture:
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, floor_texture)
            glColor3f(1, 1, 1)
        else:
            glColor3f(0.2, 0.2, 0.3)  # fallback renk

        size = 30
        glBegin(GL_QUADS)
        glTexCoord2f(0, 0);
        glVertex3f(-size, -size, -0.1)
        glTexCoord2f(10, 0);
        glVertex3f(size, -size, -0.1)
        glTexCoord2f(10, 10);
        glVertex3f(size, size, -0.1)
        glTexCoord2f(0, 10);
        glVertex3f(-size, size, -0.1)
        glEnd()

        glDisable(GL_TEXTURE_2D)

    def draw_all(self):
        # Daha karanlık atmosfer
        glClearColor(0.05, 0.05, 0.1, 1)  # Dilersen daha da koyulaştırabilirsin
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        self.setup_camera()
        self.draw_floor()

        if self.game_over:
            self.draw_text("GAME OVER", large_font, RED,
                           screen_width // 2 - 150, screen_height // 2)
            self.draw_text(f"Score: {self.score}", font, (1, 1, 1),
                           screen_width // 2 - 80, screen_height // 2 - 70)
            return

        # Draw all entities with proper textures
        self.player.draw()
        self.chaser.draw()
        self.treasure.draw()

        if self.gate_active:
            self.gate.draw()

        for obstacle in self.obstacles:
            obstacle.draw()

        # Draw HUD
        self.draw_hud()

    def draw_hud(self):
        self.draw_text(f"Score: {self.score}", font, (0, 0, 0), 20, 40)
        self.draw_text(f"Level: {self.level}/{MAX_LEVEL}", font, (0, 1, 1), 20, 80)
        self.draw_text(f"Time: {int(self.timer)}", font, (1, 1, 1), 20, 120)

    def update(self, keys, mouse_rel):
        now = time.time()
        delta_time = now - self.last_time
        self.last_time = now

        if not self.game_over:
            self.timer -= delta_time
            if self.timer <= 0:
                self.game_over = True
                self.game_over_time = now
                return

        # Camera rotation with mouse
        global CAMERA_ANGLE
        CAMERA_ANGLE = (CAMERA_ANGLE - mouse_rel[0] * CAMERA_SENSITIVITY) % 360

        # Player movement relative to camera
        move_speed = self.player.speed
        rad_angle = math.radians(CAMERA_ANGLE)

        dx, dy = 0, 0
        if keys[pygame.K_w]:
            dx += math.sin(rad_angle) * move_speed
            dy += math.cos(rad_angle) * move_speed
        if keys[pygame.K_s]:
            dx -= math.sin(rad_angle) * move_speed
            dy -= math.cos(rad_angle) * move_speed
        if keys[pygame.K_a]:
            dx -= math.cos(rad_angle) * move_speed
            dy += math.sin(rad_angle) * move_speed
        if keys[pygame.K_d]:
            dx += math.cos(rad_angle) * move_speed
            dy -= math.sin(rad_angle) * move_speed

        # Check collision before moving
        future_player = Entity(
            self.player.x + dx,
            self.player.y + dy,
            0,
            self.player.width,
            self.player.height
        )

        if not self.check_collision(future_player, self.obstacles):
            self.player.move(dx, dy)

        # Chaser movement
        dx = self.player.x - self.chaser.x
        dy = self.player.y - self.chaser.y
        dist = math.hypot(dx, dy)
        if dist > 0:
            self.chaser.x += (dx / dist) * self.chaser_speed
            self.chaser.y += (dy / dist) * self.chaser_speed

        # Check collisions
        if self.check_collision(self.player, [self.treasure]) and not self.treasure_opening:
            self.score += random.randint(10, 50)
            self.gate_active = True
            self.treasure_opening = True
            self.treasure_anim_timer = 0
            self.treasure.texture = self.textures["treasure_open"]
            self.treasure.width = 1.2
            self.treasure.height = 1.2

        if self.gate_active and self.check_collision(self.player, [self.gate]):
            if self.level >= MAX_LEVEL:
                self.game_over = True
                self.game_over_time = time.time()
            else:
                self.level += 1
                self.timer = 60
                self.init_entities()
        # Sandık açılma animasyonu kontrolü (her frame kontrol edilmeli)
        if self.treasure_opening:
            self.treasure_anim_timer += delta_time
            if self.treasure_anim_timer > 0.5:
                self.treasure = self.spawn_entity(1.2, 1.2, self.textures["treasure"])
                self.treasure_opening = False

        if self.check_collision(self.player, [self.chaser]):
            self.reset_game()

    def run(self):
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

        # Hide mouse and lock to window
        pygame.mouse.set_visible(False)
        pygame.event.set_grab(True)

        clock = pygame.time.Clock()
        while True:
            mouse_rel = pygame.mouse.get_rel()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()

            keys = pygame.key.get_pressed()
            self.update(keys, mouse_rel)
            self.draw_all()
            pygame.display.flip()

            if self.game_over and time.time() - self.game_over_time > 3:
                self.reset_game()

            clock.tick(60)


if __name__ == "__main__":
    print("Starting Dungeon Raider 3D...")
    print("Controls:")
    print("- WASD to move")
    print("- Mouse to look around")
    print("- ESC to quit")

    # Check for assets
    if not os.path.exists("assets"):
        print("\nNote: Please create an 'assets' folder and add:")
        print("player.png, chaser.png, treasure.png, gate.png, floor.png")

    Game().run()